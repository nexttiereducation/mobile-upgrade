import { Injectable } from '@angular/core';

import { ApiProvider } from './../providers/api.provider';
import { ListProvider } from './../providers/list.provider';

@Injectable()
export class SavedCollegesProvider extends ListProvider {
  constructor(private api: ApiProvider) {
    super();
  }
  public init(userId: number, isParent?: boolean) {
    if (isParent) {
      this.initializeBookmarked(userId);
    } else {
      this.initializeCollegeTrackers();
    }
  }
}
