import { Injectable } from '@angular/core';

import { ApiProvider } from './../providers/api.provider';
import { ListProvider } from './../providers/list.provider';

@Injectable()
export class BalancedCollegesProvider extends ListProvider {
  constructor(private api: ApiProvider) {
    super();
  }
}
