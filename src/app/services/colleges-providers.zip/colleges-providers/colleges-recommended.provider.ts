import { Injectable } from '@angular/core';
import { ApiProvider } from 'providers/api.provider';

import { ListProvider } from './../providers/list.provider';

@Injectable()
export class RecommendedCollegesProvider extends ListProvider {
  constructor(private api: ApiProvider) {
    super();
  }

  public init(userId: number, isParent?: boolean): void {
    this.isInitializing = true;
    // this._recommendations.next([]);
    const url = isParent
      ? `/stakeholder/recommendation/institution/`
      : `/student/${userId}/recommendation?type=I`;
    this.api.get(url)
      .subscribe(
        (data) => {
          const recs = data.json().results;
          this.nextPage = data.next;
          // this._moreToScroll.next(false);
          this.count = recs.length;
          this.all = recs;
          this.isInitializing = false;
        },
        err => {
          console.error(err);
          this.isInitializing = false;
        }
      );
  }
}
